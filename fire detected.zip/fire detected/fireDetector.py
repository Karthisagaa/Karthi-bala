import cv2
import numpy as np
import pygame

def detect_flame(frame):
    # Convert frame to HSV color space
    hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)

    # Define lower and upper bounds for the color red (flame color)
    lower_red = np.array([0, 100, 100])
    upper_red = np.array([10, 255, 255])

    # Threshold the HSV image to get only red colors
    mask = cv2.inRange(hsv, lower_red, upper_red)

    # Apply morphological operations to remove noise
    mask = cv2.erode(mask, None, iterations=2)
    mask = cv2.dilate(mask, None, iterations=2)

    # Find contours in the mask
    contours, _ = cv2.findContours(mask.copy(), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

    # Check if any contour is found
    if len(contours) > 0:
        # Flame detected
        return True
    else:
        return False

# Capture video from webcam (change the argument to a video file if needed)
cap = cv2.VideoCapture(0)

while True:
    ret, frame = cap.read()
    if not ret:
        break

    # Resize the frame for faster processing (optional)
    frame = cv2.resize(frame, (640, 480))

    # Detect flame
    flame_detected = detect_flame(frame)

    if flame_detected:
        print("Flame detected!")
        # Initialize the pygame mixer 
        pygame.mixer.init() 
        
        # Load a sound file 
        sound_file ="firemp3.mp3" 
        sound = pygame.mixer.Sound(sound_file)  

        # Play the sound
        sound.play() 
        
        # Wait for the sound to finish playing 
        pygame.time.wait(int(sound.get_length() * 1000)) 

    # Display the frame
    cv2.imshow('Frame', frame)

    # Exit if 'q' is pressed
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

# Release the video capture object and close all windows
cap.release()
cv2.destroyAllWindows()